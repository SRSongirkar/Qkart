module.exports.userController = require("./user.controller");
module.exports.authController = require("./auth.controller");
module.exports.productController = require("./product.controller");
module.exports.cartController = require("./cart.controller");
