const mongoose = require("mongoose");
const app = require("./app");
const config = require("./config/config");

let server;

// TODO: CRIO_TASK_MODULE_UNDERSTANDING_BASICS - Create Mongo connection and get the express app to listen on config.port

mongoose
  .connect(config.mongoose.url, {
    useCreateIndex: config.mongoose.options.useCreateIndex,
    useNewUrlParser: config.mongoose.options.useNewUrlParser,
    useUnifiedTopology: config.mongoose.options.useUnifiedTopology,
  })
  .then(() => {
    // console.log("Connected to the db...")
    app.listen(config.port, () => {
      console.log(`Server connected to the port ${config.port}...`);
    });
  })
  .catch((error) => {
    console.log("Somethig went wrong..", error);
  });
